

export const storeProducts = [
  {
    id: 1,
    title: "Google Pixel ",
    img: "img/product-1.png",
    price: 50000,
    company: "GOOGLE",
    info:
      "Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify.",
    inCart: false,
    count: 0,
    total: 0,
    variations: {
      colors: {
        blue: { label: "blue", price: 500 },
        white: { label: "White", price: 1000 },
       
      },
      ram: {
        "4gb": { label: "4GB RAM", price: 1100 },
        "8gb": { label: "8GB RAM", price: 2000 },
        
      },
    }
  },
  {
    id: 2,
    title: "Samsung",
    img: "img/product-2.png",
    price: 16000,
    company: "SAMSUNG",
    info:
      "Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify.",
    inCart: false,
    count: 0,
    total: 0,
    variations: {
      colors: {
        blue: { label: "blue", price: 1000 },
        white: { label: "White", price: 1500 },
        
      },
      ram: {
        "4gb": { label: "4GB RAM", price: 1000 },
        "8gb": { label: "8GB RAM", price: 2000 },
       
      },
    }
  },

  {
    id: 4,
    title: "HTC mobile ",
    img: "img/product-4.png",
    price: 18000,
    company: "htc",
    info:
      "Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify.",
    inCart: false,
    count: 0,
    total: 0,
    variations: {
      colors: {
        blue: { label: "blue", price: 1000 },
        black: { label: "black", price: 1500 },
       
      },
      ram: {
        "4gb": { label: "4GB RAM", price: 1000 },
        "8gb": { label: "8GB RAM", price: 2000 },
       
      },
    }
  },
 
  {
    id: 6,
    title: "Iphone",
    img: "img/product-6.png",
    price: 40000,
    company: "apple",
    info:
      "Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify.",
    inCart: false,
    count: 0,
    total: 0,
    variations: {
      colors: {
        blue: { label: "Black", price: 500 },
        white: { label: "White", price: 1000 },
        
      },
      ram: {
        "6gb": { label: "6GB RAM", price: 1000 },
        "8gb": { label: "8GB RAM", price: 2000 },
        
      },
    }
  },
  
];

export const detailProduct = {
  id: 1,
  title: "Google Pixel",
  img: "img/product-1.png",
  price: 61000,
  company: "google",
  info:
    "Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify.",
  inCart: false,
  count: 0,
  total: 0,
  variations: {
    colors: {
      blue: { label: "blue", price: 2000 },
      white: { label: "White", price: 1000 },
     
    },
    ram: {
      "6gb": { label: "6GB RAM", price: 1000 },
      "8gb": { label: "8GB RAM", price: 2000 },
      
    },
  }
};
