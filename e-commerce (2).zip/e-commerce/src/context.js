import React, { useState, useEffect } from "react";
import { storeProducts, detailProduct } from "./data";

const ProductContext = React.createContext();

const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [detailProductState, setDetailProduct] = useState(detailProduct);
  const [cart, setCart] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalProduct, setModalProduct] = useState(detailProduct);
  const [cartSubTotal, setCartSubTotal] = useState(0);
  const [cartTax, setCartTax] = useState(0);
  const [cartTotal, setCartTotal] = useState(0);

  useEffect(() => {
    setProducts([...storeProducts]);
    checkCartItems();
  }, []);

  const checkCartItems = () => {
    let tempCart = [...cart];
    tempCart = tempCart.filter(item => item.count > 0);
  
  
    setCart([...tempCart]);
  };
  
  const getItem = (id) => {
    return products.find((item) => item.id === id);
  };

  const handleDetail = (id) => {
    const product = getItem(id);
    setDetailProduct(product);
  };

  //   let tempProducts = [...products];
  //   const index = tempProducts.indexOf(getItem(id));
  //   const product = tempProducts[index];
  //   product.inCart = true;
  //   product.count = 1;
  //   const price = product.price; 
  //   product.total = price;

  //   setProducts([...tempProducts]);
  //   setCart([...cart, product]);
  //   setDetailProduct({ ...product });

  //   addTotals();
  // };
  // const addToCart = (id, calculatePrice) => {
  //   let tempProducts = [...products];
  //   const index = tempProducts.indexOf(getItem(id));
  //   const product = tempProducts[index];
  //   product.inCart = true;
  //   product.count = 1;
  //  product.price =  calculatePrice();
  //   product.total = calculatePrice(); 
  
  //   setProducts([...tempProducts]);
  //    setCart([...cart, product]);
   
   
  //   setDetailProduct({ ...product });
  
  //   addTotals();
  //   // getTotals()
  // };
  useEffect(() => {
    const newTotals = getTotals();
    setCartSubTotal(newTotals.subTotal);
    setCartTax(newTotals.tax);
    setCartTotal(newTotals.total);
  }, [cart]); 
  

  const addToCart = (id, calculatePrice) => {
    let tempProducts = [...products];
    const index = tempProducts.indexOf(getItem(id));
    const product = tempProducts[index];
    product.inCart = true;
    product.count = 1;
    product.price = calculatePrice();
    product.total = calculatePrice();
  
    setProducts([...tempProducts]);
     setCart([...cart, product]);
    setDetailProduct({ ...product });
 
    
    
    const newTotals = getTotals();
    setCartSubTotal(newTotals.subTotal);
    console.log(newTotals,"adda")
    setCartTax(newTotals.tax);
    setCartTotal(newTotals.total);
  };
  
  
  
  const openModal = (id) => {
    const product = getItem(id);
    setModalProduct(product);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const increment = (id) => {
    let tempCart = [...cart];
    const selectedProduct = tempCart.find((item) => item.id === id);
    const index = tempCart.indexOf(selectedProduct);
    const product = tempCart[index];
    product.count = product.count + 1;
    product.total = product.count * product.price;

    setCart([...tempCart]);
    addTotals();
  };

  const decrement = (id) => {
    let tempCart = [...cart];
    const selectedProduct = tempCart.find((item) => item.id === id);
    const index = tempCart.indexOf(selectedProduct);
    const product = tempCart[index];
    product.count = product.count - 1;

    if (product.count === 0) {
      removeItem(id);
    } else {
      product.total = product.count * product.price;
      setCart([...tempCart]);
      addTotals();
    }
  };

  const getTotals = () => {
    let subTotal = 0;
    cart.forEach((item) => (subTotal += item.total));
    const tempTax = subTotal * 0.1;
    const tax = parseFloat(tempTax.toFixed(2));
    const total = subTotal + tax;

    return {
      subTotal,
      tax,
      total,
    };
  };


  const addTotals = () => {
    const totals = getTotals();
    setCartSubTotal(totals.subTotal);
    setCartTax(totals.tax);
    setCartTotal(totals.total);
  
    getTotals();
  };

 
  
  const removeItem = (id) => {
    let tempProducts = [...products];
    let tempCart = [...cart];

    const index = tempProducts.indexOf(getItem(id));
    let removedProduct = tempProducts[index];
    removedProduct.inCart = false;
    removedProduct.count = 0;
    removedProduct.total = 0;

    tempCart = tempCart.filter((item) => item.id !== id);

    setCart([...tempCart]);
    setProducts([...tempProducts]);
    addTotals();
  };

  const clearCart = () => {
    setCart([]);
    setProducts([...storeProducts]);
    addTotals();
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        detailProduct: detailProductState,
        cart,
        modalOpen,
        modalProduct,
        cartSubTotal,
        cartTax,
        cartTotal,
        handleDetail,
        addToCart,
        openModal,
        closeModal,
        increment,
        decrement,
        removeItem,
        clearCart,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

const ProductConsumer = ProductContext.Consumer;

export { ProductProvider, ProductConsumer };
